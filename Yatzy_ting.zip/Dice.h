#ifndef DICE_H
#define DICE_H


class Dice {	
	private:
		int sides;
	public:
		Dice();
		Dice(int);
		int getValue();
		int getSides();
		void setSides(int);
};
#endif
