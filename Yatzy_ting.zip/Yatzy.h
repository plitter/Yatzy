#ifndef YATZY_H
#define YATZY_H

#include "DiceArray.h"

class Ones {
	}
