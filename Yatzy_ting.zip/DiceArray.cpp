#include "DiceArray.h"

using namespace std;

// It's not possible to call a constructor in a constructor.
//DiceArray::DiceArray() {
//	DiceArray(6, 6);
//}

DiceArray::DiceArray(int numberOfDice, int sides) {
	for(int i = 0; i<numberOfDice; i++) {
		status.push_back(false);
		values.push_back(0);
	}
	dice.setSides(sides);	
	this->numberOfDice= numberOfDice;
}

void DiceArray::throwDice() {
	for(int j = 0; j < status.size(); j++) {
		if ( status[j] == false ) {
			values[j] = dice.getValue();
		}
	}
}

vector<int> DiceArray::getValues() { return values; }

vector<bool> DiceArray::getStatus() { return status;}

void DiceArray::keep(int index) { status[index] = true; }

void DiceArray::dismiss(int index) { status[index] = false; }

