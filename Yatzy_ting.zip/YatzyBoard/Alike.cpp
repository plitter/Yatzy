#include "Alike.h"

Alike::Alike(){}

void Alike::taken() { status = true; }

void Alike::getPoints(vector<int> values) {
	int value = 0;
	int i = 6;
	for(i; i > 0; i--) {
		if ((int) count(values.begin(), values.end(), i) 
		== numberAlike) {
			value = i*number;
			break;
		}
	}
	this->setPoints(value)
}

bool Alike::getStatus() { return status; }

