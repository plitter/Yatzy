#ifndef POINTCLASS_H
#define POINTCLASS_H

class PointClass {
	protected:
		bool status; 
		int points;
		static int global_points;
	public:
		PointClass();
		void taken();
		bool getStatus();
		PointClass operator+ (PointClass);
		void setPoints(int);
		int getPoints();

};

int PointClass::global_points=0;
#endif
