#include "TwoPair.h"

void TwoPair::getValue(vector<int> values) {
	int value1 = 0;
	int value2 = 0;
	int i = 6;
        for(i; i > 0; i--) {
                if ((int) count(values.begin(), values.end(), i)
                == numberAlike) {
                        value = i*number;
                        break;
                }
        }
        for(i; i > 0; i--) {
                if ((int) count(values.begin(), values.end(), i)
                == numberAlike) {
                        value2 = i*number;
                        break;
                }
        }
	if (value2 != 0) {
		this->setPoints(value1 + value2)
	}
}
