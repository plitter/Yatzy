#ifndef FIRSTSIX_H
#define FIRSTSIX_H

#include <vector>
#include "PointClass.h"
using namespace std;

class FirstSix : public PointClass {
	private: 
		int number;
	public:
		FirstSix();
		void getValue(vector<int>);
		void setNumber(int);
};
#endif
