#ifndef ALIKE_H
#define ALIKE_H

#include <vector>

#include "PointClass.h"
using namespace std;

class Alike : public PointClass {
	private:
		int numberAlike;
	public:
		Pair();
		void getPoints(vector<int>);
};

#endif
