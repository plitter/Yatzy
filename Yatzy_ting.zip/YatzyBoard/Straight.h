#ifndef STRAIGHT_H
#define STRAIGHT_H

#include <vector>

using namespace std;

class Straight : public PointClass {
	private:
		int start, stop;
	public:
		Straight(int, int)
		void getValue(vector<int>);
}

#endif
