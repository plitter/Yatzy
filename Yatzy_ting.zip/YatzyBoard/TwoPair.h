#ifndef TWOPAIR_H
#define TWOPAIR_H

#include <vector>

using namespace std;

class TwoPair : public PointClass {
	public:
		void getValue(vector<int>);
}
