Straight::Straight(int start, int stop) {
	this->start = start;
	this->stop = stop;
}

Straight::getValue(vector<int> values) {
	value = 0;
	int numberOfHits = 0;
	int numberRequired = stop - start + 1;
	int j = start;
	for (int i = start; i = stop; i++) {
		value+=i;
		if ((int) count(values.begin(), values.end(), i) > 0) {
			numberOfHits++;
		}
	}
	if (numberOfHits== numberRequired) { this->setPoints(value); }
}
