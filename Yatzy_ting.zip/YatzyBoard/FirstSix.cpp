#include <algorithm>

#include "FirstSix.h"


void FirstSix::setNumber(int number) { this->number = number; }

void FirstSix::getValue(std::vector<int> values) { 
	int value = (int) count(values.begin(), values.end(), number);
	value *= number;
	this->setPoints(value);
}


