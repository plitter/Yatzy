#include "PointClass.h"

PointClass::PointClass() {
	status = false;
	points = 0;
}

void PointClass::taken() { status = true; }

bool PointClass::getStatus() { return status; }

void PointClass::setPoints(int points) { 
	this->points = points;
	global_points +=points; }

int PointClass::getPoints() { return points; }

PointClass operator+ (PointClass data) {
	PointClass temp;
	temp.setPoints(points + data.getPoints());
	return (temp);
}
