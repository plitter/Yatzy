#ifndef DICEARRAY_H
#define DICEARRAY_H

#include <vector>

#include "Dice.h"

using namespace std;

class DiceArray {
	private:
		vector<bool> status;
		vector<int> values;
		Dice dice;
		int numberOfDice;

	public:
		DiceArray();
		DiceArray(int, int);
		void throwDice();
		void keep(int);
		void dismiss(int);
		vector<int> getValues();
		vector<bool> getStatus();
	
};
#endif
