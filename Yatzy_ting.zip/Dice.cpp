#include <ctime>
#include <cstdlib>

#include "Dice.h"

Dice::Dice() { 
	srand(time(0));
	sides = 6; 
}

Dice::Dice(int a) { 
	srand(time(0));
	sides = a; 
}

int Dice::getValue() { 
	int value = rand() % sides + 1;
	return value;
}

int Dice::getSides() { return sides; }

void Dice::setSides(int sides) { this->sides = sides; }
